Website Link: https://saturn.csit.rmit.edu.au/~s3993934/assignment-2-website-prototype-group_11_wps_2024/assignment-2-website-prototype-group_11_wps_2024/prototype/html/index.html 

 

Project Overview: 

Our website Uni Essentials aims to create an online shopping platform for Uni Students to buy essential items required for their studies. 


Instructions: 

You will be introduced to our Homepage of Uni Essentials where you can find a menu button on the top left corner of the webpage, and you can tap on that button to see the menu options. In the bottom of the webpage, you’ll find the slideshows of the products which we are selling, and you can click on the product which will take you to the selected product’s webpage. In the bottom of the homepage, you will see the Footer where you can find the contact info of the creators of the website, A small mini map with the location, website’s socials and Privacy Policy of our website. 

On our Technology and Accessories pages we have products available for our customers. Once you have browsed through our products you can create an account on the Login/Register Page. Once you have created an account you can add any of our products to the cart and purchase them. Once you are logged in you can also participate in or spectate in discussions of our products.  


User Testing Account:
Admin Account:
Email: admin@admin.com
Password: F4cnms##

User Account:
Email: walter@gmail.com
Password: Walter@1




 
Contact Information:  

Our Team for Uni Essentials consists of: 

Nitin Bisht (s3843339@student.rmit.edu.au) 

Mandeep Sharma (s3993934@student.rmit.edu.au) 

Sara Joshi (s4036275@student.rmit.edu.au) 

Charles Jordan (s4015481@student.rmit.edu.au) 

 
